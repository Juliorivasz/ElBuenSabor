// export class UsuarioDTO {
//   private idAuth0: string;
//   private email: string;
//   private nombre: string;
//   private apellido: string;
//   private telefono: string;
//   private imagen: string;
//   private password: string;
//   private rolesidAuth0s: string[];

//   constructor(
//     idAuth0: string,
//     email: string,
//     nombre: string,
//     apellido: string,
//     telefono: string,
//     imagen: string,
//     password: string,
//     rolesidAuth0s: string[],
//   ) {
//     this.idAuth0 = idAuth0;
//     this.email = email;
//     this.nombre = nombre;
//     this.apellido = apellido;
//     this.telefono = telefono;
//     this.imagen = imagen;
//     this.password = password;
//     this.rolesidAuth0s = rolesidAuth0s;
//   }

//   // Getters
//   public getidAuth0(): string {
//     return this.idAuth0;
//   }

//   public getEmail(): string {
//     return this.email;
//   }

//   public getNombre(): string {
//     return this.nombre;
//   }

//   public getApellido(): string {
//     return this.apellido;
//   }

//   public getTelefono(): string {
//     return this.telefono;
//   }

//   public getImagen(): string {
//     return this.imagen;
//   }

//   public getPassword(): string {
//     return this.password;
//   }

//   public getRolesidAuth0s(): string[] {
//     return this.rolesidAuth0s;
//   }

//   // Setters
//   public setidAuth0(idAuth0: string): void {
//     this.idAuth0 = idAuth0;
//   }

//   public setEmail(email: string): void {
//     this.email = email;
//   }

//   public setNombre(nombre: string): void {
//     this.nombre = nombre;
//   }

//   public setApellido(apellido: string): void {
//     this.apellido = apellido;
//   }

//   public setTelefono(telefono: string): void {
//     this.telefono = telefono;
//   }

//   public setImagen(imagen: string): void {
//     this.imagen = imagen;
//   }

//   public setPassword(password: string): void {
//     this.password = password;
//   }

//   public setRolesidAuth0s(rolesidAuth0s: string[]): void {
//     this.rolesidAuth0s = rolesidAuth0s;
//   }
// }
