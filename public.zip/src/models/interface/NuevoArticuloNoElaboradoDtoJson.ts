export interface NuevoArticuloNoElaboradoDtoJson {
  nombre: string;
  descripcion: string;
  precioVenta: number;
  dadoDeAlta: boolean;
  idCategoria: number;
  imagenUrl?: string;
}
