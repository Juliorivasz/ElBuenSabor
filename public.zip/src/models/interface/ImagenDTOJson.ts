export interface ImagenDTOJson {
  url: string;
}
