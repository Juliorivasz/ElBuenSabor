export interface ArticuloManufacturadoDetalleDtoJson {
  idArticuloInsumo: number;
  cantidad: number;
}
