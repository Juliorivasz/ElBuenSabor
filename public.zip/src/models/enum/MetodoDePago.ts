export enum MetodoDePago {
  EFECTIVO = "EFECTIVO",
  MERCADO_PAGO = "MERCADO_PAGO",
}
