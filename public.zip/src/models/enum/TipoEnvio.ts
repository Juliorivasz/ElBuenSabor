export enum TipoEnvio {
  DELIVERY = "DELIVERY",
  RETIRO_EN_LOCAL = "RETIRO_EN_LOCAL",
}
