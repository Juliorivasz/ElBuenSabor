export type routeType = {
  name: string;
  path: string;
  element: React.FC;
};
