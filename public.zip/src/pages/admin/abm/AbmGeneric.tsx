//
import { Products } from "../../products/Products";

export const AbmGeneric: React.FC = () => {
  return <Products />;
};
